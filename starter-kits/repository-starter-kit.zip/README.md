# TITLE
DESCRIPTION

## How It Works
Getting started with TITLE is really easy. [View the online tutorial](#) or dig through the `index.html` file.

## Changelog
* v1.0 (DATE)
  * Initial release.

## License
TITLE is free to use under the [MIT License](http://opensource.org/licenses/MIT).
